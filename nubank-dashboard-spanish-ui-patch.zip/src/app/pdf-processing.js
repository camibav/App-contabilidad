import {
  appendOutput,
  resetFileInput,
  setOutput,
  setStatus,
} from "../ui/dashboard-ui.js";
import {
  extractEmbeddedPdfText,
  extractTextWithOcr,
  loadPdfFromFile,
} from "../services/pdf.service.js";
import {
  mergeMovementsById,
  mergeProcessedFiles,
  parseNuMovements,
} from "../domain/movements.js";
import { buildDashboardStats } from "../domain/dashboard-stats.js";
import { saveDashboardData } from "../services/storage.service.js";
import { getLearnedCategoryRules } from "../services/category-rules-storage.service.js";
import { formatError } from "../utils/formatters.js";

export function createPdfInputChangeHandler({ elements, state, renderDashboard }) {
  return async function handlePdfInputChange(event) {
    const selectedFiles = Array.from(event.target.files ?? []);

    if (!selectedFiles.length) {
      setStatus(elements, "No se seleccionó ningún PDF. Los datos guardados permanecen cargados.");
      return;
    }

    const pdfFiles = selectedFiles.filter(isPdfFile);
    const rejectedFiles = selectedFiles.filter((file) => !isPdfFile(file));

    if (!pdfFiles.length) {
      setStatus(
        elements,
        "No se seleccionaron archivos PDF válidos. Los datos guardados permanecen cargados."
      );
      setOutput(
        elements,
        "Archivos rechazados:\n" +
          rejectedFiles.map((file) => `- ${file.name}`).join("\n")
      );
      resetFileInput(elements);
      return;
    }

    const rawTextByFile = [];
    const processingErrors = [];

    setOutput(
      elements,
      buildInitialProcessingMessage({
        pdfFiles,
        rejectedFiles,
      })
    );

    try {
      for (const [index, file] of pdfFiles.entries()) {
        const fileNumber = index + 1;
        const totalFiles = pdfFiles.length;

        try {
          setStatus(
            elements,
            `Procesando PDF ${fileNumber} de ${totalFiles}: ${file.name}`
          );

          const rawText = await extractTextFromPdfFile({
            elements,
            file,
            fileNumber,
            totalFiles,
          });

          if (!rawText.trim()) {
            appendOutput(
              elements,
              `\nNo se detectó texto legible en: ${file.name}\n`
            );
            continue;
          }

          rawTextByFile.push(buildRawTextBlock(file.name, rawText));

          const result = applyParsedResult({
            state,
            rawText,
            fileName: file.name,
            renderDashboard,
          });

          appendOutput(
            elements,
            "\n" +
              `Archivo procesado: ${file.name}\n` +
              `Movimientos detectados en este archivo: ${result.newMovementsCount}\n` +
              `Movimientos acumulados: ${result.totalMovements}\n`
          );
        } catch (error) {
          console.error(error);

          processingErrors.push({
            fileName: file.name,
            error,
          });

          appendOutput(
            elements,
            "\n" +
              `Error al procesar el archivo: ${file.name}\n` +
              formatError(error) +
              "\n"
          );
        }
      }

      renderFinalDashboardState({
        state,
        rawTextByFile,
        renderDashboard,
      });

      if (!state.data) {
        setStatus(elements, "El procesamiento finalizó, pero no se detectaron movimientos.");
        return;
      }

      if (processingErrors.length) {
        setStatus(
          elements,
          `Procesamiento finalizado con ${processingErrors.length} error(es). Archivos: ${state.data.files.length}. Total de movimientos: ${state.data.movements.length}.`
        );
        return;
      }

      setStatus(
        elements,
        `Procesamiento finalizado. Archivos: ${state.data.files.length}. Total de movimientos: ${state.data.movements.length}.`
      );
    } finally {
      resetFileInput(elements);
    }
  };
}

async function extractTextFromPdfFile({ elements, file, fileNumber, totalFiles }) {
  appendOutput(
    elements,
    "\n" +
      `--- PROCESANDO ARCHIVO ${fileNumber} DE ${totalFiles} ---\n` +
      `Archivo: ${file.name}\n`
  );

  setStatus(elements, `Cargando PDF ${fileNumber} de ${totalFiles}: ${file.name}`);

  const pdf = await loadPdfFromFile(file);

  appendOutput(elements, `PDF cargado correctamente.\nPáginas: ${pdf.numPages}\n`);

  setStatus(elements, `Intentando extraer texto embebido: ${file.name}`);

  const embeddedText = await extractEmbeddedPdfText(pdf, (message) =>
    setStatus(elements, `[${file.name}] ${message}`)
  );

  if (embeddedText.trim()) {
    setStatus(elements, `Extracción de texto embebido finalizada: ${file.name}`);
    return embeddedText;
  }

  appendOutput(
    elements,
    "No se encontró texto embebido.\n" +
      "Este PDF parece estar basado en imágenes.\n" +
      "Iniciando extracción OCR...\n"
  );

  setStatus(elements, `Cargando motor OCR: ${file.name}`);

  const ocrText = await extractTextWithOcr(pdf, (message) =>
    setStatus(elements, `[${file.name}] ${message}`)
  );

  if (!ocrText.trim()) {
    setStatus(
      elements,
      `El OCR finalizó, pero no detectó texto legible: ${file.name}`
    );
    return "";
  }

  setStatus(elements, `Extracción OCR finalizada: ${file.name}`);

  return ocrText;
}

function applyParsedResult({ state, rawText, fileName, renderDashboard }) {
  const learnedCategoryRules = getLearnedCategoryRules();
  const newMovements = parseNuMovements(rawText, fileName, {
    learnedCategoryRules,
  });

  const previousMovements = Array.isArray(state.data?.movements)
    ? state.data.movements
    : [];

  const mergedMovements = mergeMovementsById(previousMovements, newMovements);
  const dashboardStats = buildDashboardStats(mergedMovements);
  const processedAt = new Date().toISOString();

  state.data = {
    ...state.data,
    fileName,
    files: mergeProcessedFiles(state.data?.files, fileName, {
      legacyFileName: state.data?.fileName,
      legacyProcessedAt: state.data?.processedAt,
      currentProcessedAt: processedAt,
    }),
    processedAt,
    movements: mergedMovements,
    summary: dashboardStats.summary,
  };

  saveDashboardData(state.data);

  state.tablePagination.page = 1;

  renderDashboard();

  return {
    newMovementsCount: newMovements.length,
    totalMovements: mergedMovements.length,
  };
}

function renderFinalDashboardState({ state, rawTextByFile, renderDashboard }) {
  if (!state.data) {
    return;
  }

  const debugRawText = rawTextByFile.length
    ? rawTextByFile.join("\n\n")
    : "--- NO HAY TEXTO BRUTO NUEVO DISPONIBLE ---";

  renderDashboard({ debugRawText });
}

function buildInitialProcessingMessage({ pdfFiles, rejectedFiles }) {
  const selectedFilesMessage =
    "Archivos PDF seleccionados:\n" + pdfFiles.map((file) => `- ${file.name}`).join("\n");

  if (!rejectedFiles.length) {
    return selectedFilesMessage + "\n";
  }

  return (
    selectedFilesMessage +
    "\n\nArchivos rechazados:\n" +
    rejectedFiles.map((file) => `- ${file.name}`).join("\n") +
    "\n"
  );
}

function buildRawTextBlock(fileName, rawText) {
  return `--- TEXTO BRUTO DEL ARCHIVO: ${fileName} ---\n${rawText}`;
}

function isPdfFile(file) {
  return file.type === "application/pdf" || file.name.toLowerCase().endsWith(".pdf");
}
